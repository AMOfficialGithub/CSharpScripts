﻿//Declaring a variable
int num1;

//assign a value to a variable
num1 = 13;
Console.WriteLine(num1);

//Declaring and initalizing a variable in one go
int num2 = 23;

//Applyig mathmatical operations

int sum = num1 + num2;

Console.WriteLine(sum);

//Using concatenation
Console.WriteLine("num is" + num1);
Console.WriteLine("num1 " + num1 + " num2 " + num2 + " is " + sum);

double d1 = 3.1415;
double d2 = 5.1;
double dDiv = d1 / d2;
Console.WriteLine("d1/d2 is " + dDiv);

float f1 = 3.145f;
float f2 = 5.1f;
float fDiv = f1 / f2;
Console.WriteLine("f1 and f2 is" + fDiv);

double dIDiv = d1 / num1;
Console.WriteLine("d1 / num1 is " + dIDiv);