﻿// Dictionaries are generic collections.
// key - value 
// Auto - Car

using System.Security.Cryptography;
using System.Collections.Generic; // Adding this namespace for Dictionary

// Initializing the dictionary with integer keys and string values
Dictionary<int, string> myDictionary = new Dictionary<int, string>()
{
    {1, "one" },
    {2, "two" },
    {3, "three" }
};

// Employee objects with values of age and rate
Employee[] employees =
{
    new Employee("CEO", "April", 95, 200),
    new Employee("Manager", "Gwyn", 44, 100),
    new Employee("HR", "Jeff", 68, 220),
    new Employee("Secretary", "Lisa", 56, 48),
    new Employee("Lead Developer", "Atlas", 100, 150),
    new Employee("Intern", "Jason", 55, 90)
};

// Creating a dictionary to store employees with their roles as keys
Dictionary<string, Employee> employeesDirectory = new Dictionary<string, Employee>();
foreach (Employee emp in employees)
{
    employeesDirectory.Add(emp.Role, emp);
}

//Check if key exist
string key = "CEO";
Employee emp1 = employeesDirectory[key];
if(employeesDirectory.ContainsKey(key))
{
    Console.WriteLine("Employee Name: {0}, Role: {1}, Salary {2}", emp1.Name, emp1.Role, emp1.Salary);
}
else
{
    Console.WriteLine("No employee found with this key {0}", key);
}
// Fetching data from the dictionary
emp1 = employeesDirectory["CEO"];

// Employee class representing individual employees
class Employee
{
    // Properties like Role, Name, Age, and Rate
    public string Role { get; set; }
    public string Name { get; set; }
    public int Age { get; set; }
    public float Rate { get; set; }

    // Yearly Salary calculation
    public float Salary
    {
        get
        {
            // Salary calculation: Rate per hour * 8 hours/day * 5 days/week * 4 weeks/month * 12 months/year
            return Rate * 8 * 5 * 4 * 12;
        }
    }

    // Constructor to initialize Employee object
    public Employee(string role, string name, int age, float rate)
    {
        // Assigning values to properties
        this.Role = role;
        this.Name = name;
        this.Age = age;
        this.Rate = rate;
    }

    //A dictionary is a collection of struct pairs
}

