﻿using ReadOnlyAndWriteOnlyProperties;

Car myCar = new Car();
Console.WriteLine("Maxspeed is" + myCar.MaxSpeed);
