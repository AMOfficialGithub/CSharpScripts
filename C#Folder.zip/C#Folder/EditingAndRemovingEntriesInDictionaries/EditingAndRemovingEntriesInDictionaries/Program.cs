﻿using System;
using System.Collections.Generic;

// Define Employee class representing individual employees
class Employee
{
    // Properties like Role, Name, Age, and Rate
    public string Role { get; set; }
    public string Name { get; set; }
    public int Age { get; set; }
    public float Rate { get; set; }

    // Yearly Salary calculation
    public float Salary
    {
        get
        {
            // Salary calculation: Rate per hour * 8 hours/day * 5 days/week * 4 weeks/month * 12 months/year
            return Rate * 8 * 5 * 4 * 12;
        }
    }

    // Constructor to initialize Employee object
    public Employee(string role, string name, int age, float rate)
    {
        // Assigning values to properties
        Role = role;
        Name = name;
        Age = age;
        Rate = rate;
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Initializing the dictionary with integer keys and string values
        Dictionary<int, string> myDictionary = new Dictionary<int, string>()
        {
            {1, "one" },
            {2, "two" },
            {3, "three" }
        };

        // Employee objects with values of age and rate
        Employee[] employees =
        {
            new Employee("CEO", "April", 95, 200),
            new Employee("Manager", "Gwyn", 44, 100),
            new Employee("HR", "Jeff", 68, 220),
            new Employee("Secretary", "Lisa", 56, 48),
            new Employee("Lead Developer", "Atlas", 100, 150),
            new Employee("Intern", "Jason", 55, 90)
        };

        // Creating a dictionary to store employees with their roles as keys
        Dictionary<string, Employee> employeesDirectory = new Dictionary<string, Employee>();
        foreach (Employee emp in employees)
        {
            employeesDirectory.Add(emp.Role, emp);
        }

        // Check if key exists and update if found
        string keyToUpdate = "HR"; // Example key to update
        if (employeesDirectory.ContainsKey(keyToUpdate))
        {
            // Update the employee object with the specified key
            employeesDirectory[keyToUpdate] = new Employee("HR", "Eleka", 26, 18);
            Console.WriteLine("Employee with key '{0}' updated successfully.", keyToUpdate);
        }
        else
        {
            Console.WriteLine("No employee found with the key '{0}'.", keyToUpdate);
        }

        // Fetching data from the dictionary
        Employee emp1 = employeesDirectory["CEO"];
        Console.WriteLine("Employee '{0}' fetched successfully.", emp1.Name);

        // Removing an item from the dictionary
        string keyToRemove = "Intern"; // Example key to remove
        if (employeesDirectory.Remove(keyToRemove))
        {
            Console.WriteLine("Employee with Role/Key {0} was removed successfully.", keyToRemove);
        }
        else
        {
            Console.WriteLine("No employee found with the key '{0}'.", keyToRemove);
        }

        // Printing the contents of the dictionary
        Console.WriteLine("\nContents of employeesDirectory:");
        foreach (var kvp in employeesDirectory)
        {
            Console.WriteLine("Key: {0}, Value: {1}", kvp.Key, kvp.Value.Name);
        }
    }
}
