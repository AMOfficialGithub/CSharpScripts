﻿using System.ComponentModel;

Console.WriteLine(Add(5, 5)); //Called and parameters filled in the method called.
//A method can be used as a argument, such as the above. 
//Creating a return that has to do with an int.
//Two parameters have ints
int Add(int one1, int two2)
    {
    return one1 + two2;
    
}

//Methods that can be called with one another
Console.WriteLine(Add(Add(1, 2), Add(4, 3)));

//CHALLENGE Create a method that multiples two values to each other
//and returns the result of the multiplication

Console.WriteLine(Multiply(4, 5));

int Multiply(int multi1, int multi2)
{
    return multi1 * multi2;
}

//Use double for the parameter, if int is used then it will cut off the double as a return
double Divide(double div1, double div2)
{
    //Result is returned as a double type
    return div1 / div2;
}

Console.WriteLine(Divide(3, 5));

