﻿using System.Security.Cryptography;

int counter = 0;
while(counter < 10)
{
    Console.WriteLine("Run the code in the While Loop{0}", counter);
    //increment
    counter++;
}

   //Challenge, when the enter key is pressed the numbeer of people increase.
        int peopleOnBus = 0; // Initial number of people on the bus

        Console.WriteLine("Press Enter to increase the number of people on the bus. Press any other key to exit.");

        while (true)
        {
            var keyInfo = Console.ReadKey(); // Read a key press

            if (keyInfo.Key == ConsoleKey.Enter) // Check if the key is Enter
            {
                peopleOnBus++; // Increment the number of people
                Console.WriteLine($"\nThere are {peopleOnBus} people on the bus.");
            }
            else
            {
                break; // Exit the loop if any key other than Enter is pressed
            }
        }

        Console.WriteLine("Program ended.");
    


