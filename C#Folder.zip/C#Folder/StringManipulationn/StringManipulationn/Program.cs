﻿int age = 36;
string name = "Alfonso";

//String concatenation
Console.WriteLine("String conncatenation");
Console.WriteLine("Hello my name is " + name + " and I am " + age + " years old");

//String formatting is used in index
Console.WriteLine("Hello, this name is  {0}, and I am {1}, years old!", name, age);

//CHALLENGE: CREATE A VARIABLE AND USE IT IN THE STRING FORMATTING

string name2 = "April";
Console.WriteLine("Hello, my other name is {0}, and I am {1} years old", name2, age);

//String interpolation uses the $ at the start which will allow us to do the following
Console.WriteLine($"Hello, my name is {name} and I am {age} years old.");

//Verbatim strings start with @ and tells the compiler ot take the string literal
//ignore any spaces or characters like \ These can be used when doing windows paths such as C:\User\etc

Console.WriteLine(@"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.");

