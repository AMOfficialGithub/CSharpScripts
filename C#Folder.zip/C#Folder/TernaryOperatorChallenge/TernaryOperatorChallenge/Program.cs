﻿/*
 *We have studied ternary operators and their usage so here is a small challenge for you. Let's create a small application that takes a temperature value as input and checks if the input is an integer or not.

If the input value is not an integer value, it should print to the console "Not a valid Temperature".

And if the input value is the valid integer then it should work as mentioned below.

    If input temperature value is <=15 it should write "it is too cold here" to the console.

    If input temperature value is >= 16 and is <=28 it should write "it is ok" to the console.

    If the input temperature value is > 28 it should write "it is hot here" to the console.

Make sure to use ternary operators and not if statements to check for the three conditions, however you can use if statement for the other conditions like to check if the entered value is a valid integer or not.


*/

Console.WriteLine("Please put in a number to be checked by the system");

string temperature = Console.ReadLine();
int newTemp;

//Checking to see if the temperature entered is a number
try
{
   
    newTemp = Int32.Parse(temperature);
}
catch (Exception)
{
    Console.WriteLine("Not a valid Temperature");
    return;  // Exit the program if the temperature input is invalid
}

string stateOfMatter = newTemp <= 15 ? "It is too cold here" :
                        newTemp >= 16 && newTemp <= 28 ? "It is okay" :
                        "It is hot here";

Console.WriteLine(stateOfMatter);
