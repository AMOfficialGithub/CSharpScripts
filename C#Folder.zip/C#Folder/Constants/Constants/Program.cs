﻿//Constants are immutable values which are known (not changeable after created)
//for the lifetime of the program.

//constants as fields
const double PI = 3.141599265359;
const int weeks = 52, months = 12; //Can store in one line

//CHALLENGE CREATE A CONSTANT WITH YOUR BIRTHDAY OF IT'S STRING

const string myBDay = "03/21/1989";

Console.WriteLine("My birthday is going to be {0}",myBDay);
