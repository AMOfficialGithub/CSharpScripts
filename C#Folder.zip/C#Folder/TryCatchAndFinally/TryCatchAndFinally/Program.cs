﻿Console.WriteLine("Please enter in a number");


string userInput = Console.ReadLine();
try //It tries this method
{ int userInputAsInt = int.Parse(userInput); }
catch(FormatException) //The catch will activate if the try fails
{
    Console.WriteLine("Format Exception. Wrong input. Please enter in a number next time");
}catch(OverflowException) //General exception
{
    Console.WriteLine("Overflow. Too small or too large.");
}
finally //Will always execute regardless of catch
{
    Console.WriteLine("Finally executes when try or catch are finished!");
}

//CHALLENGE: Divide by zero. Use two variables

try
{
    Console.WriteLine("Enter in the first number");
    string firstNum = Console.ReadLine();
    Console.WriteLine("Enter in the second number");
    string secondNum = Console.ReadLine();
    int firstConvert = Int32.Parse(firstNum);
    int secondConvert = Int32.Parse(secondNum);
    int result = firstConvert / secondConvert;
    Console.WriteLine(result);
}
catch(DivideByZeroException)
{
    Console.WriteLine("You cannot divide by zero!");
}