﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    internal class Post
    {
        //Field of post static makes it available outside of this script
        private static int currentPostId;

        //Properties
        //Protected means it can only be used by this class and derived classes
        protected int ID { get; set; }
        protected string Title { get; set; }
        protected string SendByUsername { get; set; }
        protected bool IsPublic { get; set;
        
        }

        //Creating default constructor.
        public Post()
        {
            ID = 0;
            Title = "MyFirstPost";
            IsPublic = true;
            SendByUsername = "April McBroom";
        }

        //Constructor with several parameters

    }
}
