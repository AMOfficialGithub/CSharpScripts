﻿//This is the old program, the static is to call the object without having to rename
//the program
//A method is a peice of code that can be executed without having to re-write it again.

//The internal keyword locks the program inside of the file. It cannot be accessed outside.
internal class Program
{
    static void Main(String[] args)
    {
        Console.WriteLine("Hello World!");
        Console.Beep();
        //Challenge write your name, then a beep, then followed by another beep.

        Console.WriteLine("Another peice of code before the two beeps");
        Console.Beep();
        Console.Beep();
        Console.WriteLine("I have beeped 3 times!");
    }
}
