﻿Console.WriteLine("Hello, World!");
//Comment by two slashes at the beginning of the line.
//Below will print to the console of the text.
//Challenge! Say hello and your name
Console.WriteLine("Hello, April!");

