﻿//Class names like ClientActivity

//Method names like CalculateValue

//Camel causing for arguments like firstNumber

//Local variables like itemCount

//Avoid abbreviations such as uC for userControl

//Don't use numbers at the start of variables, such as 3Cars. Use at the end like cars3

//Try to avoid cars_engine, the underscore. Exception is at the beginning _carsEngine.

//Try to avoid the capital String, Int32, and Boolean. Use it's lower-case.