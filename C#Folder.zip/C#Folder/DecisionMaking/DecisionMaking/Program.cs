﻿int temperature = 10;

if(temperature < 10)
{
    Console.WriteLine("Put on a coat, it's cold out there!");
}
if(temperature == 10)
{
    Console.WriteLine("It's 10 degrees outside");
}
if(temperature > 10)
{
    Console.WriteLine("Cozy and warm!");
}
//CHALLENGE, EDIT THE CODE ABOVE THAT THE WEATHER CAN BE ENTERED MANUALLY
Console.WriteLine("Enter in the temperature manually");
 string newTemp = Console.ReadLine();
int convertedTemp = Int32.Parse(newTemp);

if (convertedTemp < 20)
{
    Console.WriteLine("Put on a coat, it's cold out there!");
}
else if (convertedTemp == 20)
{
    Console.WriteLine("It's 20 degrees outside");
}
else 
{//Anything greater than 20
    Console.WriteLine("Cozy and warm!");
}

