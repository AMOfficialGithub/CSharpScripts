﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    internal class ElectricalDevice
    {
        public bool IsOn { get; set; }
        //Bradn name of the radio
        public string Brand { get; set; }

        public ElectricalDevice(bool isOn, string brand)
        {
            IsOn = isOn;
            Brand = brand;
        }

       public void SwitchOn()
        {
            IsOn = true;
        }

        public void SwitchOff()
        {
            IsOn = false;
        }

        public void WatchDevice()
        {
            if (IsOn)
            {
                Console.WriteLine("Electrical Device is on!");
            }
            else
            {
                Console.WriteLine("Electrical Device is switched off, switch it on first");
            }
        }
    }
}

