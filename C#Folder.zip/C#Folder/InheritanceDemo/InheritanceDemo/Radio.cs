﻿using System;

namespace InheritanceDemo
{
    // Child Class, ElectricalDevice is the parent class/base class
    internal class Radio : ElectricalDevice
    {
        public Radio(bool isOn, string brand) : base(isOn, brand)
        {

        }

        public void ListenRadio()
        {
            // Check if the radio is on
            if (IsOn)
            {
                // Listen to the radio
                Console.WriteLine("Listening to the radio!");
            }
            else
            {
                // Print error message
                Console.WriteLine("Radio switch is off. Turn it back on first.");
            }
        }
    }
}
