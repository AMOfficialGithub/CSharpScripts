﻿namespace Stacks
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Defining a stack
            //Define the type of the stack(Only one type per stack)
            Stack<int> stack = new Stack<int>();
            stack.Push(1); //adding an item to the stack
            stack.Push(2);
            stack.Push(3);
            //To see what the stack has in the latest item
            Console.WriteLine("the top value is {0} in the stack", stack.Peek());

            //To remove an item from the stack
            int myStackItem = stack.Pop();
            Console.WriteLine("Popped item {0}",myStackItem);
            Console.WriteLine("Top value in the stack is {0}", stack.Peek());

            //CHALLENGE Create a while loop that will stop after executing the items
          while(stack.Count > 0)
            {
                //Pop will return the element that was removed from the stack
                Console.WriteLine("The Top value {0} was removed from the stack", stack.Pop());
                //Print the stack count
                Console.WriteLine("Curretn stack count is {0}", stack.Count);
            }

            //Reversing an array
            int[] numbers = new int[] { 8, 2, 3, 4, 7, 6, 1 };
            //Defining a new stack of int
            Stack<int> myStack = new Stack<int>();

            Console.WriteLine("the numbers in the array are :");
            //foreach number in our array
            foreach(int number in numbers)
            {
                //print it
                Console.Write(number + " ");
                //push it into our stack (add)
                myStack.Push(number);
            }
        }
    }
}
