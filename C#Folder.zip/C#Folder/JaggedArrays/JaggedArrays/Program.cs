﻿// Store an array within an array, which is an array section.

// How to declare a jagged array
int[][] jaggedArray = new int[3][]; // Define the arrays to have

// Adding values based on position(first) and how many values(second).
jaggedArray[0] = new int[5];
jaggedArray[1] = new int[3];
jaggedArray[2] = new int[2];

jaggedArray[0] = new int[] { 2, 3, 5, 7, 11 };
jaggedArray[1] = new int[] { 1, 2, 3 };
jaggedArray[2] = new int[] { 13, 21 };


//CHALLENGE, Print out the Rows of the Array
// Print the values of jaggedArray
for (int i = 0; i < jaggedArray.Length; i++)
{
    // Print the index of the current array
    Console.WriteLine("Array at index {0}:", i);

    // Loop through each element of the current array
    for (int k = 0; k < jaggedArray[i].Length; k++)
    {
        // Print the value of the current element
        Console.WriteLine("    Element at index {0} is {1}", k, jaggedArray[i][k]);
    }
}
