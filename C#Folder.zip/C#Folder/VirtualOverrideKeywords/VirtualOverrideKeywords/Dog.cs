﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualOverrideKeywords
{
    //Inherit from Animal Parent/Base Class
    internal class Dog: Animal
    {
        public bool IsHappy { get; set; }
        public Dog(string name, int age): base(name,age)
        {
            IsHappy = true;
        }

        //Override the Eat Method

        public override void Eat()
        {
            //To call the eat method from our base class
            base.Eat();
            
            }
        public override void MakeSound()
        {
            Console.WriteLine("Woof!");
        }

        public virtual void Play()
        {//Check to see if the dog is happy
          if(IsHappy)
            {
                base.Play();
            }
        }

    }
    }

