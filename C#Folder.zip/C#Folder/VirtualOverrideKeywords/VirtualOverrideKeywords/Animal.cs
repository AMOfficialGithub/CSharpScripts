﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualOverrideKeywords
{

    //This is the base class
    internal class Animal
    {
        //Challenge will have the properties age, name, hungry, a method called make sound, eat and play

        //name properties
        public string Name { get; set; }

        public int Age { get; set; }

        public bool isHungry { get; set; }


        //Simple constructor
        public Animal(string name, int age)
        {
            Name = name;
            Age = age;

            isHungry = true;
        }

        //Make virtual so it can be overidden by classes that use Animal
        public virtual void MakeSound()
        {

        }

        public virtual void Eat()
        {
            if(isHungry)
            {
                Console.WriteLine($"{Name} is eating");
            }
            else
            {
                Console.WriteLine($"{Name} is not hungry");
            }
        }

        public virtual void Play()
        {
            Console.WriteLine($"{Name} is playing");
        }
    }
}