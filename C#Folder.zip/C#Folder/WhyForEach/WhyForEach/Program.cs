﻿int[] numbers = { 1, 2, 3, 4, 5 };

//The counter is number, and numbers is the array.

//In each element of that doesn't need index manipulation
foreach(int number in numbers)
{
    Console.WriteLine(number);
}
//A for loop gives more control over the itteration process and needs index manipulation.

for(int counter = 0; counter < numbers.Length; counter+=2)
{
    Console.WriteLine(numbers[counter]);
}

//While loops are best used when you don't know how many times to loop.
string input;
do
{
    Console.WriteLine("Please enter a valid number");
    input = Console.ReadLine();
} while (!int.TryParse(input, out _));