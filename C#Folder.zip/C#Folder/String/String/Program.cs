﻿//String as a captial letter is the class of string
//string with a small letter is the keyword. The standard is the small letter.

string myName = "April";
Console.WriteLine(myName);

string message = "My  name is " + myName;

Console.WriteLine(message);

//the ToUpper makes the entire data upper-case.
string capMessage = message.ToUpper();

Console.WriteLine(capMessage);
//CHALLENGE:Create a new variable and make it a type string with lower-case letters.
capMessage = message.ToLower();
Console.WriteLine(capMessage);
///<summary>
///This is XML documentation, used to document what methods do what. Put it before the method.
/// </summary>
/// 
//Prints and keeps the cursor on the same line
Console.Write("Text Here");

//Prints and puts the cursor on the next line
Console.WriteLine("This goes onto a next line the cursor");

//Takes a single input of type string and returns the ASCII value
Console.Read();

//Takes a string or integer input and returns it as the Output value
Console.ReadLine();

//Waits to enter a key
Console.ReadKey();

Console.Write("Enter a string and press enter");
string readInput = Console.ReadLine();//Takes in user input
Console.WriteLine("You have entered {0}" + readInput);

Console.Write("Enter a string and press enter");
int asciiValue = Console.Read();
Console.WriteLine("ASCII value is {0}", asciiValue);
