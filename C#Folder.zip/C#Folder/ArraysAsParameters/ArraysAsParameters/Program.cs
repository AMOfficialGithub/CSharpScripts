﻿//Creating the array of integers
int[] studentsGrades = new int[] { 15, 13, 8, 12, 6, 16 };
double averageResult = GetAverage(studentsGrades);

foreach(int grade in studentsGrades)
{
    Console.WriteLine(grade);
}
Console.WriteLine("The average is {0}", averageResult);



//Calculate all the averages in the array that is handed as athe argument
static double GetAverage(int[] gradesArray)
{
    //Creating the length of the GradesArray
    int size = gradesArray.Length;
    //Can carry the average
    double average;
    int sum = 0;
    //Runs through the whole array and adds value to the sum
    for(int i = 0; i <size; i++)
    {
        sum += gradesArray[i];
    }
    average = (double)sum / size;
    return average;
}

/**CHALLENGE. Create an array of happiness in the main method and assign
 * 5 values to it. This method should increase the argument by 2, for each entry
 * Call this method in the main method and use happiness as the argument
 * Create a foreach loop in the main method to write all values onto the console.
 * 
 */

//Creating the array and issuing 5 values to it.
int[] happiness = new int[5] { 1, 2, 3, 4, 5 };


// Call the method to increase each value by 2
SunIsShining(happiness);

// Print all values of the array onto the console using foreach loop
foreach (int value in happiness)
{
    Console.WriteLine(value);
}
//Creating the method with an int array as it's parameter
void SunIsShining(int[] Happiness)
{
    for (int i = 0; i < Happiness.Length; i++)
    {
        //Increasing the Happiness by 2
        Happiness[i] += 2;
    }

}


