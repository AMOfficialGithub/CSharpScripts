﻿using System.Diagnostics.Metrics;

for (int counter = 0; counter < 5; counter++)//Counter, then condition, then incrementation.
{
    Console.WriteLine(counter); //Prints out the numbers in the for loop, not the position!
}

//Create a counter that increments by five
for(int counter2 = 0; counter2 < 10; counter2 +=5)
{
    Console.WriteLine("This is increment by five only {0} ", counter2);
}

Console.WriteLine("All loops are finished");

//Write a for loop which only prints out the odd numbers from 0 to twenty.
//Must start at 1 because 1 is an odd number. Then adding 2 to 1 will keep it odd.

for (int counter3 = 1; counter3 <= 20; counter3 += 2)
{
    Console.WriteLine("This is an odd number: {0}", counter3);
}
