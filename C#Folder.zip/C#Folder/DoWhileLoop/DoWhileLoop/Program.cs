﻿//Setting up the counter.
int counter = 0;
//This is always ran once before anything else in the do.
do
{
    Console.WriteLine(counter);
    //Increase the counter by 1
    counter++;
} while (counter < 5); //The while code is done after the do. It is the condition

//Program that will take user input and execute code based upon it

int lengthOfText = 0;
string wholeText = "";
do
{
    Console.WriteLine("Please enter the name of a friend");
    string nameOfAFriend = Console.ReadLine();
    //Give the length of the text the user entered and added to the current length.
    int currentLength = nameOfAFriend.Length;
    lengthOfText += currentLength;
    wholeText += nameOfAFriend;
} while (lengthOfText < 20);
Console.WriteLine("Thanks, that's enough.{0}", wholeText);