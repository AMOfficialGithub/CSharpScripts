﻿
    string stringForFloat = "0.85"; // datatype should be float
    string stringForInt = "12345"; // datatype should be int

    float myFloat = float.Parse(stringForFloat);
    int myInt = int.Parse(stringForInt);

Console.WriteLine("This float is {0} and is  {1}", myFloat, myInt);
