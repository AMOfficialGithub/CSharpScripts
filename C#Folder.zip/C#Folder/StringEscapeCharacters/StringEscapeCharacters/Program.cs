﻿string s1 = "this is a \"string\" with \na / and a colon: ";//This will treat the \
//as part of the string. the \n will create a new line
Console.WriteLine(s1);


