﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shortcuts
{
    internal class UsefulShortcuts
    {

        //Use F12
        //Ctrl and - navigates back to the other class.

        //ctrl and shift and - goes forward

        //Intellisense can be used when writing code as well too

        //Ctrl and space 

        //Ctrl and k for a precursor for another shortcut
        //ctrl c comments out the line
        //ctrl k and u uncomments out a line

        //ctrl and r and ctrl r again reads the method
        //ctrl - is the other method name.
        //ctrl tab jumps to another file.

        public void AnotherMethod()
        {
            Console.WriteLine("I am another method!");
        }
        //ctor is the code snippet for a constructor
        public UsefulShortcuts()
        {
            Console.WriteLine("UsefulShortcuts object was created");
        }

       
       //Other code snippets
       //try and tab
   
    }
}
