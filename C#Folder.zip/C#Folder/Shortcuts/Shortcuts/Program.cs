﻿
using Shortcuts;

Console.WriteLine("Hello, World!");
UsefulShortcuts useful = new UsefulShortcuts();
useful.AnotherMethod();