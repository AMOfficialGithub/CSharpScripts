﻿double myDouble = 13.4;
int myInt;

//To cast double into int(contain only whole numbers)
//Explicit Conversion
int thisInt = (int)myDouble;

Console.WriteLine(thisInt);

//Implicit Conversion(smaller type goes into a bigger type)
int num = 122345;
long bigNum = num;

float myFloat = 13.7f;
double myNewDouble = myFloat;
Console.WriteLine(myNewDouble);

//Type Conversion. Turns myDouble to a string format
string myString = myDouble.ToString();
Console.WriteLine(myString);


//CHALLENGE: Convert myfloat to a string as well
string myFloatString = myFloat.ToString();
Console.WriteLine(myFloatString);

//Converting a boolean to a string type
bool sunIsShining = true;
string myBoolString = sunIsShining.ToString();
Console.WriteLine(myBoolString);