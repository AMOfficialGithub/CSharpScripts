﻿/**
 * Add a deriving class "VideoPost" with property VideoURL, Length;
 * 
 * Create the required constructors to create a VideoPost
 * adjust the ToString method accordingly
 * Create an instance of VideoPost
 * 
 * More advanced---
 * 
 * use Timer and Callback method here
 * create fields as required
 * 
 * add member methods "Play" which should write the current duration of the video
 * And "Stop" which should stop the "timer" and write "stopped at {0}s" onto the console.
 *Play the video after creating the instance and pause it, when the user presses any key.
 *
 */



