﻿using Setters;

Car myCar = new Car();
//Changing a variable but not directly
myCar.setName("New Vehicle with a special name");
myCar.Details();
//Setting the name of the vehicle
myCar.setName("Changing the name of the vehicle");
//Calling the getName method
Console.WriteLine(myCar.getName());
//Grabbing the getter GetHorse()
Console.WriteLine(myCar.getHorse());
