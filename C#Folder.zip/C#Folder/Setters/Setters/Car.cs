﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Setters
{
    
        internal class Car
        {
            private string _name;
            private int _hp;
            private string _color;

        //Makes a change to a variable
        //Add conditions when the name is being set
        public void setName(string name)
        {
            //If the user enters in no name
            if (name == "")
            {
                _name = "DefaultName";
            }
            else
            {
                //Setting the private variable to the parameter of string name
                _name = name;
            }

            
           
        }
        //Creating a Getter
        //Needs a return type
        public string getName()
        {
            return _name+" suffix";
        }
        public Car()
            {
                Console.WriteLine("I am the default constructor");
                _name = "Car";
                _hp = 25;
                _color = "red";
            }

            private void Drive()
            {
                Console.WriteLine("Car is driving");
            }

            public void Stop()
            {
                Console.WriteLine("Car is stopped");
            }

            public void Details()
            {
                Console.WriteLine($"Name: {_name}, HP: {_hp}, Color: {_color}");
            }

        //CHALLENGE, create a getter that returns the horse-power of a car
        public int getHorse()
        {
            return _hp;
        }
        }
    }


