﻿
static int MinV2(params int[] numbers)
{
    //Setting the minimum value to the MaxValue that an integer can hold
    int min = int.MaxValue;

    //Comparing values
    foreach(int number in numbers)
    {
        if (number < min)
            min = number;
    }

    return min;
}

int min = MinV2(6, 4, 7, 8, 9, 10, 12); //Passing 7 values
Console.WriteLine("The minimum is {0}", min);