﻿

using FirstClass;

/**A class in C# is a blueprint for creating objects.
 * It defines a set of properties(data attributes)
 * and methods(functions) that an object of the class will have.
 */

//An object called audi that is the datatype called Car.
//What is stored in audi is a new Car(create a new instance of a class which is object
//allocates memory on the heap for a new object. Returns a reference to the object.
//The reference is stored in the variable for later use)

Car audi = new Car();//The parethensis is used to call the constructor of a object
audi.Drive(); //Calling the method drive

//Using user input and calling the method
string userInput = Console.ReadLine();
if (userInput == "1")
{
    audi.Stop();
}else
{
    Console.WriteLine("The car is still driving!");
}

//Creating the car object using default constructor
Car bmw = new Car();