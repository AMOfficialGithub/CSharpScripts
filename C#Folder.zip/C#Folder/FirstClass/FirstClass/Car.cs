﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstClass
{
    //Internal means it can only be accessed from the same assembly
    internal class Car
    {
        //Default constructor
         public Car()
        {
            Console.WriteLine("A car object was created");
        }

        public void Drive()
        {
            Console.WriteLine("Car is driving");
        }

        //CHALLENNGE: Create a stop method

        public void Stop()
        {
            Console.WriteLine("The car has stopped");
        }
    }
}
