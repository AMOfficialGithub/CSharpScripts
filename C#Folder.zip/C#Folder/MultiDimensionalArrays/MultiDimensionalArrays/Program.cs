﻿//These types are based on their commas

//Creating a 2D/MultiArray
string[,] matrix;

//3D Array
int[,,] threeD;

//How to initalize the above

//two dimensional array
int[,] array2D = new int[,]
{
    {1,2,3 }, //Row zero
    {4,5,6 }, //Row 1
    {7,8,9 } //Row 2
};

//To access the above

Console.WriteLine("Central value is {0}", array2D[1,1]);

//CHALLENGE Try to access the 7

Console.WriteLine("This is {0}", array2D[2, 0]);

//Running a 3D array

string[,,] array2De = new string[,,]
{//First Dimension(outer curly bracket)
    {//Second Dimension(this curly bracket)
        //3rd Dimension(the numbers)
        {"000","001" },
        {"010","011" },
        {"Hi there","What's up?" },
},
{
        {"100","101" },
        {"110","111" },
        {"Here is another row","For the road!" }
}
};

//CHALLENGE, ACCESS THE FOLLOWING ARRAY
//Access which dimension(0), the row(2), and the value(0)
Console.WriteLine(array2De[0, 2,0]);

//Multi-Dimension Arrays
string[,] array2DString = new string[3, 2]//3 rows and two enteries per row
{
    {"one","two" },
    {"three","four" },
    {"five","six" }
};

//CHALLENGE, CHANGE THE FOUR TO CHICKEN!
//Select the row and the value
array2DString[1, 1] = "Chicken";

//Print using Console.WriteLine();
Console.WriteLine(array2DString[1,1]);

//To find out the dimensions of an array

int dimensions = array2DString.Rank; //Gets the dimensionns, such as a 2D having 2

Console.WriteLine("The value of the dimensions is {0}",dimensions);

//Creating an array without specifying the rank
int[,] array2D2 = { { 1, 2 }, { 3, 4 } }; //One row, two values for the first one.

