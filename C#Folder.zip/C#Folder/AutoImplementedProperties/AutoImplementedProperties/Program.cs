﻿
using AutoImplementedProperties;

Car myCar = new Car();
myCar.MaxSpeed = 180;
//Can access the getter of the hidden variable MaxSpeed
//Auto-implemented property
Console.WriteLine("Max speed is " + myCar.MaxSpeed);