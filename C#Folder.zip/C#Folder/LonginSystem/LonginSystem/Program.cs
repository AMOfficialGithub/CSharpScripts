﻿using System.Runtime.CompilerServices;

Console.WriteLine("Put in your username here");
string username = Console.ReadLine();
Console.WriteLine("Put in your password here");
string password = Console.ReadLine();
Console.WriteLine("Please verify the username here");
string verifyUsername = Console.ReadLine();
Console.WriteLine("Please verify the password here");
string verifyPassword = Console.ReadLine();

if(username == verifyUsername && password == verifyPassword)
{
    Console.WriteLine("You have successfully logged in!");
}
else
{
    Console.WriteLine("Either the password or the username is incorrect. Try again");
}
