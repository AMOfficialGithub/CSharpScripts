﻿
using ConstructorAndMemoryVariables;

Car audi = new Car("Audi A4",45,"Green");
audi.Drive();

Car bmw = new Car("BMW M5",100);

//Creating the object with the Drive Method
bmw.Drive();
audi.Details();
Console.WriteLine("Press 1 to stop the car!");
string userInput = Console.ReadLine();

if(userInput == "1")
{
    audi.Stop();
}

//Partial Constructor
Car myCar = new Car();
myCar.Details();