﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorAndMemoryVariables
{
    //Internal means it can only be accessed from the same assembly
    internal class Car
    {

        //Private field creation. Typically used to store data
        //The convention is to underscore the name.
        //This is a global private field
        private string _name;
        private int _hp;
        private string _color;



        //Default constructor
        //When a new car is created, will need a new name from it
        public Car(string name, int hp, string color = "Blue")
        {
            _color = color;
            _hp = hp; //Assigning the hp into the global hp
            _name = name; //Give the name of the car to the private field _name
            Console.WriteLine(name + "was created");
        }

        //Multiple Constructor
        public Car(){
            _name = "Car";
            _hp = 0;
            _color = "Red";
            }

            public void Drive()
            {
                Console.WriteLine(_name + "is driving");
            }

            //CHALLENGE: Create a stop method
            //Member Methods
            public void Stop()
            {
                Console.WriteLine(_name + "has stopped");
            }

        public void Details()
        {
            Console.WriteLine($"The car called {_name}, has {_hp} hp in it and the color is {_color}");
        }
        }
    }

