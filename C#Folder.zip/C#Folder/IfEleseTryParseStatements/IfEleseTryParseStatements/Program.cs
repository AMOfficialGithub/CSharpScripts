﻿int temperature = 10;  // Initial temperature

Console.WriteLine("Enter the temperature manually:");
string newTemp = Console.ReadLine();

int convertedTemp;  // Declare convertedTemp variable

if (int.TryParse(newTemp, out convertedTemp))
{
    Console.WriteLine($"Temperature set to: {convertedTemp} degrees.");
}
else
{
    convertedTemp = 0;
    Console.WriteLine("Value entered was not a number. Temperature set to 0 degrees.");
}
