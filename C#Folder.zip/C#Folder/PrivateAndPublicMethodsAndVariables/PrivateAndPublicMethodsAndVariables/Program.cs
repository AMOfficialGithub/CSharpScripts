﻿
using System;
using PrivateAndPublicMethodsAndVariables;

//Creating the car objects with parameters
Car audi = new Car();
Car bmw = new Car();

Console.WriteLine("Press 1 to stop the car!");
string userInput = Console.ReadLine();

//Partial Constructor
Car myCar = new Car();
//This line 12 is executed, where the new Car() with no parameters as the default constructor
//By default, it is named Car
//In line 16 we over-ride the default name called Car and changes it to myCar1
myCar._name = "myCar1";

//Encapsulation is the pratice of hiding the internal state of an object
//These are private variables, which is data integrity.
