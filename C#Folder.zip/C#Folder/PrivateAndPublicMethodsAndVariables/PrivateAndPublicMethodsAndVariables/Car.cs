﻿using System;

namespace PrivateAndPublicMethodsAndVariables
{
    internal class Car
    {
        public string _name;
        private int _hp;
        private string _color;

        public Car()
        {
            Console.WriteLine("I am the default constructor");
            _name = "Car";
            _hp = 0;
            _color = "red";
        }

        private void Drive()
        {
            Console.WriteLine("Car is driving");
        }

        public void Stop()
        {
            Console.WriteLine("Car is stopped");
        }

        public void Details()
        {
            Console.WriteLine($"Name: {_name}, HP: {_hp}, Color: {_color}");
        }
    }
}

