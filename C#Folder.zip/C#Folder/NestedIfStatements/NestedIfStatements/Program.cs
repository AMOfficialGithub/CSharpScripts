﻿bool isAdmin = false;
bool isRegistered = true;
string userName = "Admin";  // Set the default value for the userName variable

if (isRegistered) //If the registration is true
{
    Console.WriteLine("Hi there, registered user");
    if (!string.IsNullOrEmpty(userName))  // Check if userName is not empty
    {
        Console.WriteLine("Hi there, " + userName);
        if (userName.Equals("Admin")) //If the userName contains Admin is true
        {
            Console.WriteLine("Hi there, Admin");
            isAdmin = true;  // Set isAdmin to true if the userName is "Admin"
        }
    }
}
