﻿//Check if counter is below 10, then continue to increment
for(int counter = 0; counter < 10; counter++)
{
    Console.WriteLine(counter); //This will print out the number

    if(counter == 3)
    {
        Console.WriteLine("At 3 we stop.");
        break; //Comes out of the for loop statement
    }
}
//Check if counter is below 10, then continue to increment
for (int counter1 = 0; counter1 < 10; counter1++)
{
    Console.WriteLine(counter1); //This will print out the number

    if (counter1 == 3)
    {
        Console.WriteLine("At 3 we skip and continue on.");
        continue; //Will come out of the current entry
    }
}

