﻿using System;
/**
 * Create a user Login System, where the user can first register and then Login in. The Program should check if the user has entered the correct username and password, wenn login in (so the same ones that he used when registering).
As we haven't covered storing data yet, just create the program in a way, that registering and logging in, happen in the same execution of it.
User If statements and User Input and Methods to solve the challenge.
 */
class UserLoginSystem
{
    //Setting up the variables
    static string username;
    static string password;

    static void Main()
    {
        //Calling the methods
        RegisterUser();
        Login();
    }

    static void RegisterUser()
    {
        Console.WriteLine("Welcome to User Registration!");
        Console.Write("Enter your username: ");
        username = Console.ReadLine();
        Console.Write("Enter your password: ");
        password = Console.ReadLine();
        Console.WriteLine("Registration successful!");
    }
    static void Login()
    {
        Console.WriteLine("Welcome to User Login!");
        Console.Write("Enter your username: ");
        string inputUsername = Console.ReadLine();
        Console.Write("Enter your password: ");
        string inputPassword = Console.ReadLine();

        if (inputUsername == username && inputPassword == password)
        {
            Console.WriteLine("Login successful! Welcome, " + username + "!");
        }
        else
        {
            Console.WriteLine("Incorrect username or password. Please try again.");
        }
    }
}

