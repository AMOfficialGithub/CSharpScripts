﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace MembersAndFinalizersDestructors
{
    internal class Members
    {

        //Member private field
        private string memberName;
        private string jobTitle;
        private int salary = 150000;
        //member - public field
        public int age;

        //member property-exposes jobTitle safely -properties start with a capital letter
        public string JobTitle {
            get {
                return jobTitle;
            }
            set {
                jobTitle = value;
            }
        }

        //public member Method - can be called from other classes

        //This is true;
        public void Introducing(bool isFriend)
        {
            if(isFriend)
            {
                SharingPrivateInfo();
            }
            else
            {
                Console.WriteLine("Hi, my name is {0} and my job title is {1}, " +
                    "i'm {2} years old", memberName,jobTitle,age);
            }
        }

        private void SharingPrivateInfo()
        {
            Console.WriteLine("My salary is {0}", salary);
        }

        //Member Constructor

        public Members()
        {
            age = 30;
            memberName = "Lucy";
             salary = 600000;
            jobTitle = "Software Developer";
            Console.WriteLine("Object Created");
        }
        //member-finalizer-destructor
        //A Class can only have 1 finalizer
        //Cannot be inherited, overloaded, or called. Only for a specific class.
        ~Members()
        {
            //Cleanup statements
            Console.WriteLine("Deconstruction of Members Object");
            Debug.Write("This Deconstruction of Members Object");
        }
    }
}
