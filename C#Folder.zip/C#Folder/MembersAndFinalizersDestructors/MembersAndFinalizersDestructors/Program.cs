﻿
//Calling the namespace that is going to be used in the main program file
using MembersAndFinalizersDestructors;


Members member1 = new Members();
member1.Introducing(true);
