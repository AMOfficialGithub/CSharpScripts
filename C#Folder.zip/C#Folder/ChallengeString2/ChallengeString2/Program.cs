﻿/**This application asks the user to input a string in the first line like “Enter a string here: ”.

In the Second Line, it should ask for the character to search in the string which you have entered in the first line like “Enter the character to search: ”

On the third line, it should write the index of the first occurrence of the searched character from the string.

Now on concatenation...

It should then ask to enter the first name and once the name is written and the enter button is pressed, it should ask to enter the last name.

It should then show your full name printed in a single line like in my case the output will be "Denis Panjuta". Output can be different in your case. Try to store the full name in a variable, before displaying it.
**/

Console.WriteLine("Enter a string here");

string userInput = Console.ReadLine();

Console.WriteLine("Enter in the character to search");

char searchInput = Console.ReadLine()[0]; //Will search for the first letter in the string
//This will be stored in the index1, using the string from userInput looking for the Index of searchInput.
int index1 = userInput.IndexOf(searchInput);

//Write the index of the first occurence of the searched character from the string
Console.WriteLine(index1);

//Concatenation
Console.WriteLine("What is your first name?");
string firstName = Console.ReadLine();
Console.WriteLine("What is your last name?");
string lastName = Console.ReadLine();

string fullName = firstName + lastName;

Console.WriteLine("Your first and last name is {0} {1}", firstName, lastName);


