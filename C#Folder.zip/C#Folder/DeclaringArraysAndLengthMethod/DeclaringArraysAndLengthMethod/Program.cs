﻿

//Declaring a new array with 5 values and initalizing the values
int[] grades = new int[5];

//Adding values to the grades
grades[0] = 20;
grades[1] = 15;
grades[2] = 19;
grades[3] = 10;
grades[4] = 7;

//Getting the grades from index 0
Console.WriteLine("grades at index 0 : {0}", grades[0]);

//Changing the value from user input
string input = Console.ReadLine();
grades[0] = int.Parse(input);

Console.WriteLine("grades at index 0 : {0}", grades[0]);


//Second iniatlizing
int[] gradesOfMathStudentsA = { 20, 12, 13, 8, 8 };

//Third Initalizing
int[] gradesOfMathStudentsB = new int[] { 15, 20, 30, 18, 15, 3 };

//To get the length of an array
Console.WriteLine("Length of grades{0} ",gradesOfMathStudentsA.Length);