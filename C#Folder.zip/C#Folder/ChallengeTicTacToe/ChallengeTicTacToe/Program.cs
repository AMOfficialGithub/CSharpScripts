﻿//CHALENGE use 2D Arrays, switch cases to solve the problem

using System;

class Program
{
    static char[,] playField =
    {
        {'1','2','3' },{'4','5','6'}, {'7','8','9'}
    };

    static void SetField()
    {
        Console.WriteLine(" | | ");
        Console.WriteLine(" {0} | {1} | {2}", playField[0, 0], playField[0, 1], playField[0, 2]);
        Console.WriteLine("___|___|___");
        Console.WriteLine(" | | ");
        Console.WriteLine(" {0} | {1} | {2}", playField[1, 0], playField[1, 1], playField[1, 2]);
        Console.WriteLine("___|___|___");
        Console.WriteLine(" | | ");
        Console.WriteLine(" {0} | {1} | {2}", playField[2, 0], playField[2, 1], playField[2, 2]);
        Console.WriteLine("___|___|___");
    }

    static bool IsWinner(char symbol)
    {
        // Check rows, columns, and diagonals for a win
        return (playField[0, 0] == symbol && playField[0, 1] == symbol && playField[0, 2] == symbol) ||
               (playField[1, 0] == symbol && playField[1, 1] == symbol && playField[1, 2] == symbol) ||
               (playField[2, 0] == symbol && playField[2, 1] == symbol && playField[2, 2] == symbol) ||
               (playField[0, 0] == symbol && playField[1, 0] == symbol && playField[2, 0] == symbol) ||
               (playField[0, 1] == symbol && playField[1, 1] == symbol && playField[2, 1] == symbol) ||
               (playField[0, 2] == symbol && playField[1, 2] == symbol && playField[2, 2] == symbol) ||
               (playField[0, 0] == symbol && playField[1, 1] == symbol && playField[2, 2] == symbol) ||
               (playField[0, 2] == symbol && playField[1, 1] == symbol && playField[2, 0] == symbol);
    }

    static bool IsBoardFull()
    {
        // Check if all positions are filled
        foreach (char c in playField)
        {
            if (c != 'X' && c != 'O')
                return false;
        }
        return true;
    }

    static void Main(string[] args)
    {
        int player = 1; // Player 1 starts
        bool win = false;

        do
        {
            SetField();
            Console.WriteLine("Player {0}, enter your move (1-9):", player);
            int input = int.Parse(Console.ReadLine());

            // Check if input is valid
            if (input < 1 || input > 9 || playField[(input - 1) / 3, (input - 1) % 3] == 'X' || playField[(input - 1) / 3, (input - 1) % 3] == 'O')
            {
                Console.WriteLine("Invalid input! Try again.");
                continue;
            }

            // Update the playfield
            playField[(input - 1) / 3, (input - 1) % 3] = (player == 1) ? 'X' : 'O';

            // Check for a win
            if (IsWinner((player == 1) ? 'X' : 'O'))
            {
                SetField();
                Console.WriteLine("Player {0} wins!", player);
                win = true;
            }
            else if (IsBoardFull())
            {
                SetField();
                Console.WriteLine("It's a draw!");
                win = true;
            }

            // Switch players
            player = (player == 1) ? 2 : 1;

        } while (!win);

        Console.ReadLine();
    }
}
