﻿
//Used to declare implicity type variables.
//Telling the compiler to determine the datatype
//based on the value it's assigned.

var number = 0; //int
var num = 1; //int
var text = "text"; //string
var isTrue = false; //boolean

//Var variables cannot have a null data such as var newVar = null;
