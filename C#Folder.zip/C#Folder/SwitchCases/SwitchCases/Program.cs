﻿using System.ComponentModel.Design.Serialization;

int age = 25; //Comparison variable

switch(age)//Comparing this value in the switch
{
    case 15:
        Console.WriteLine("Too young to go to the secret club!");
        break; //Must break out of the switch-statement
    case 25:
        Console.WriteLine("You can go to the secret club!");
        break;

    default: //called when the others above are not true
        Console.WriteLine("This is called when the above is not true");
        break;
}

//CHALLENGE reproduce the above as an if statement

if(age == 15)
{
    Console.WriteLine("Sorry, your too young to be here!");
}
else if(age == 25)
{
    Console.WriteLine("Welcome to the secret club! Enjoy your stay");

}
else
{
    Console.WriteLine("What age are you?");
}

//String switch statement
string username = "April";

switch(username)
{
    case "Denis":
        break;
    case "April":
        Console.WriteLine("This is my username!");
        break;
    case "root":
        Console.WriteLine("You are a root username");
        break;

    default:
        Console.WriteLine("Username is unknown");
        break;
}