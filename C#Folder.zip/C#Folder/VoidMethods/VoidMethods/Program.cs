﻿//public is not needed since top-level statements are used.
//Void mean that it will not return anything.
//There are no arguments/parameters in this method
void WriteSomething()
{
    Console.WriteLine("This is a method with a void in it");
}

//Calling the method
WriteSomething();


//Calling this method means that the parameter must be filled in the calling
void WriteSomethingSpecific(string myText)
{
    Console.WriteLine(myText);
}
//Calling the method with one parameter
WriteSomethingSpecific("This method uses a parameter/argument and is called from a method");