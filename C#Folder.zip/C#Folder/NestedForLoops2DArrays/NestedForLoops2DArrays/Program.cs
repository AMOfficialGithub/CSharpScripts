﻿
//2D Array with 3 rows and 3 columns
int[,] matrix =
{
    {1,2,3 },
    {4,5,6 },
    {7,8,9 }
};

//The iteration is item, in the 2D array called matrix
//A for each loop should only be used with a known array length.
//It cannot re-assign items to the for-each loop.
foreach(int item in matrix)
{
    //Write the reference to the value in one line
    Console.Write(item + " ");
}

//To adjust the array, use a nested for loop.
Console.WriteLine("2D array printed using a for-each nested for loop");
//GetLength is for the dimension(the row)
//The outer loop is for the individual rows

for(int i = 0; i <matrix.GetLength(0); i++)
{
    //To travel through the individual colums use an innerloop

    for (int j = 0; j < matrix.GetLength(1); j++)
    {
        Console.WriteLine(matrix[i, j] + " ");
    }
}//i will stay at zero until j is gone through. Then j being zero in the first interration.
//Then J is at one(from what we put in GetLength, and increases by 1.
//The dimension is the column, which is why j will be done with it's execution.

