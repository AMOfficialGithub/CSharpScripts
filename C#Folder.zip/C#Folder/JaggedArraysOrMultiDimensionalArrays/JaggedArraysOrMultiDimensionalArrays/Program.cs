﻿
//A jagged array is also known as an array of arrays. Can be different dimensions and sizes

//Delcare and initalize a jaggedArray
int[][] triangle = new int[][]
{
    new int [] {1},
    new int [] {2,3},
    new int [] {4,5,6},
    new int []{ 7,8,9,10}
};

//Use a for each loop to print out each row of the triangle.
foreach (int[] row in triangle)
{
    foreach(int number in row)
    {
        Console.WriteLine(number);
    }
}
//Multi dimensional arrays are of the same size, which is ideal for math operations

//Declare and initalize the 2D array
int[,] grid = new int[,]
{
    {1,2 },
    {3,4 },
    {5,6 },
    {7,8 }
};

//Outer foorlop is used to iterate over the rows of the grid array
for (int i = 0 ; i < grid.GetLength(0); i++)
{


    //the inner is to iterate over the columns.
    for (int j = 0; j < grid.GetLength(1); j++)
    {
        Console.WriteLine(grid[i, j]);
    }
}
//Use jaggedArrays while creating complex data structures and elements of different sizes
//Multidimensional arrays for mathamatical arrays on the same grid size.