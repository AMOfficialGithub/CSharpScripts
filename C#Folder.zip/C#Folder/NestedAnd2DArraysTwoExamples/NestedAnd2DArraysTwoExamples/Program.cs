﻿
//2D Array with 3 rows and 3 columns
int[,] matrix =
{
    {1,2,3 },
    {4,5,6 },
    {7,8,9 }
};

//The iteration is item, in the 2D array called matrix
//A for each loop should only be used with a known array length.
//It cannot re-assign items to the for-each loop.
foreach (int item in matrix)
{
    //Write the reference to the value in one line
    Console.Write(item + " ");
}

//To adjust the array, use a nested for loop.
Console.WriteLine("2D array printed using a for-each nested for loop");
//GetLength is for the dimension(the row)
//The outer loop is for the individual rows

for (int i = 0; i < matrix.GetLength(0); i++)
{
    //To travel through the individual colums use an innerloop

    for (int j = 0; j < matrix.GetLength(1); j++)
    {
        //Check the matrix at the i,j position, filtering for odd numbers
        if (matrix[i, j] % 2 == 1)
            Console.WriteLine(matrix[i, j] + " ");
        else
        {
            Console.Write(" ");
        }
    }
}
//CHALLENGE, take the nested for-loop and adjust it so the console.writeline will
//not print out all elments of the matrix but only the odd numbers.
//if statements will need to be used as well.


//How to print the diagnols of a matrix below
//(1,5,9)

for (int i = 0; i < matrix.GetLength(0); i++)
{
    //To travel through the individual colums use an innerloop

    for (int j = 0; j < matrix.GetLength(1); j++)
    {
        //Check the matrix at the i,j position,diagnol positioning
        if (i == j)
            Console.WriteLine(matrix[i, j] + " ");
        else
        {
            Console.Write(" ");
        }
        Console.WriteLine("");
    }
}

//CHALLENGE: Do the above with one for loop below

for(int i= 0; i < matrix.GetLength(0); i++)
{
    Console.WriteLine(matrix[i, i]);
}

//CHALLENGE Find a Logic that will print out 3,5,7 instead

//Two counter variables
for (int e = 0, g = 2; e <matrix.GetLength(0); e++, g--)
{
    Console.WriteLine(matrix[e, g]);
}