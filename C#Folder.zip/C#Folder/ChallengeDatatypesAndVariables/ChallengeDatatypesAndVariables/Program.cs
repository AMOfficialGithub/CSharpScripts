﻿/**Create each datatype that is available here. Write each value to the console.
 * https://learn.microsoft.com/en-us/previous-versions/visualstudio/visual-studio-2008/ms228360(v=vs.90)?redirectedfrom=MSDN
 */

byte unsignedInteger = 3;
Console.WriteLine(unsignedInteger);
sbyte signedInteger = 45;
Console.WriteLine(signedInteger);
int signedInt = 50303030;
Console.WriteLine(signedInt);
uint unSignedInt = 40303030;
Console.WriteLine(unSignedInt);
short signedShort = 3292;
Console.WriteLine(signedShort);
ushort unsignedShort = 455;
Console.WriteLine(unsignedShort);
long signedLong = 39383828282;
Console.WriteLine(signedLong);
ulong unsignedLongInteger = 3939233929;
Console.WriteLine(unsignedLongInteger);
float unsignedFloat = 2984838383f;
Console.WriteLine(unsignedFloat);
double doublePrecisionFloat = 39393993;
Console.WriteLine(doublePrecisionFloat);
char singleCode = 'A';
Console.WriteLine(singleCode);
bool isTrue = true;
Console.WriteLine(isTrue);
string myString = "This string here";
Console.WriteLine(myString);
decimal myDecimal = 34345.89m;
Console.WriteLine(myDecimal);

/**Then create two values of type string. 
The first one should say "I control text"

The second one should be a whole number. Then use the Parse method in order to convert that string to an integer.

Add each an output for each of the variables and write it onto the console. (WriteLine)**/

string textControl = "I control text";
string wholeNumber = "35";
//Converting string to an integer
int myLittleInt = Int32.Parse(wholeNumber);

Console.WriteLine("The following string has been turned to an int with the value of {0}", myLittleInt);