﻿using System;
using System.Collections.Generic;

namespace QueueExample
{
    class Program
    {
        static void Main(string[] args)
        {
            // Defining a Queue
            Queue<int> queue = new Queue<int>();

            // Adding items to the queue(this will be added last by order(FIFO))
            queue.Enqueue(1);

            // To look at the queue's items use the below
            Console.WriteLine("The value at the front of the queue is: {0}", queue.Peek());

            // Adding more values
            queue.Enqueue(2);
            Console.WriteLine("The value at the front of the queue is: {0}", queue.Peek());

            queue.Enqueue(3);
            Console.WriteLine("The value at the front of the queue is: {0}", queue.Peek());

            // To get rid of an item is dequeue
            int queueItem = queue.Dequeue();
            Console.WriteLine("The value at the front of the queue is: {0}", queue.Peek());

            while (queue.Count > 0)
            {
                Console.WriteLine("The value at the front of the queue is: {0}", queue.Dequeue());
                Console.WriteLine("The current queue count is {0}", queue.Count);
            }

            // Process orders
            ProcessOrders();
        }

        static void ProcessOrders()
        {
            Order[] branch1Orders = Order.ReceivedOrdersFromBranch1();
            Order[] branch2Orders = Order.ReceivedOrdersFromBranch2();

            Queue<Order> ordersQueue = new Queue<Order>();

            foreach (Order o in branch1Orders)
            {
                ordersQueue.Enqueue(o);
            }

            foreach (Order o in branch2Orders)
            {
                ordersQueue.Enqueue(o);
            }

            while (ordersQueue.Count > 0)
            {
                Order currentOrder = ordersQueue.Dequeue();
                currentOrder.ProcessOrder();
            }
        }
    }

    class Order
    {
        // OrderID
        public int OrderId { get; set; }
        // Quantity of the order
        public int OrderQuantity { get; set; }

        // Simple Constructor
        public Order(int id, int orderQuantity)
        {
            this.OrderId = id;
            this.OrderQuantity = orderQuantity;
        }

        // Print message on the screen that the order was processed
        public void ProcessOrder()
        {
            // Print the message
            Console.WriteLine($"Order {OrderId} processed!");
        }

        // This method will create an array of orders and return it
        public static Order[] ReceivedOrdersFromBranch1()
        {
            // Creating new orders array
            Order[] orders = new Order[]
            {
                new Order(1, 5),
                new Order(2, 4),
                new Order(6, 10)
            };
            return orders;
        }

        // Branch Order 2
        public static Order[] ReceivedOrdersFromBranch2()
        {
            // Creating new orders array
            Order[] orders = new Order[]
            {
                // The first values are unique, such as 7, 9, 11
                new Order(7, 8),
                new Order(9, 10),
                new Order(11, 12)
            };
            // Returns the orders
            return orders;
        }
    }
}
