﻿Console.WriteLine("price is {0}, pi is {1}, at is {2}", 32, 3.14, '@');
//Params mean it'll accept as many params as you give it as type object
static void ParamsMethod(params string[] sentences)
{
    for(int i = 0; i < sentences.Length; i++)
    {
        Console.WriteLine(sentences[i] + " ");
    }
}

ParamsMethod("this", "is", "a", "long", "string", "when", "will", "it", "end?");

//Creating a method that allows objects as well

static void ParamsMethod2(params object[] stuff)
{
    foreach(object obj in stuff)
    {
        Console.WriteLine(obj + " ");
    }
}

ParamsMethod2("Hey!!", 2, 4.15f, 5.16, '@',true);