﻿

using Inheritance2;

Post post1 = new Post("Thanks for the birthday wishes!", true,"April Redman");
Console.WriteLine(post1.ToString());
ImagePost imagePost1 = new ImagePost("Check out my new shoes", "April Redman", "https://www.google.com", true);

Console.WriteLine(imagePost1.ToString());

//CHALLENGE, CREATE a ToString Method in Image Post to inform about the link.