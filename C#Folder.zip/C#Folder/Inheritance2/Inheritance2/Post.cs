﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance2
{
    internal class Post
    {
        private static int currentPostId;

        //properties
        protected int ID { get; set; }
        protected string Title { get; set; }
        protected string SendByUsername { get; set; }
        protected bool isPublic { get; set; }

        //Default constructor is called implicity if derive class does not invoke a base class constructor

        public Post()
        {
            ID = 0;
            Title = "My First Post";
            isPublic = true;
            SendByUsername = "April Redman";
        }

        //Instance constructor that has 3 parameters
        public Post(string Title, bool isPublic, string sendByUsername)
        {
            this.ID = GetNextID();
            this.Title = Title;
            this.SendByUsername = sendByUsername;
            this.isPublic = isPublic;
        }

        protected int GetNextID()
        {
            return ++currentPostId;
        }

        public void Update(string title, bool isPublic)
        {
            this.Title = title;
            this.isPublic = isPublic;
        }

        //Override method inherited from System.Object
        public override string ToString()
        {
            //return it in this format below
            return String.Format("{0} - {1} - by {2}", this.ID, this.Title, this.SendByUsername);
        }
    }
}
