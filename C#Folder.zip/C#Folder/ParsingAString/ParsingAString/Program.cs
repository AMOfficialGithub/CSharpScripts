﻿string myString = "15";

string mySecondString = "13";

string result = myString + mySecondString;

Console.WriteLine(result);

//Parse the strings to add them for integers

int myInt = Int32.Parse(myString);
int myInt2 = Int32.Parse(mySecondString);

int result2 = myInt + myInt2;

Console.WriteLine(result2);
