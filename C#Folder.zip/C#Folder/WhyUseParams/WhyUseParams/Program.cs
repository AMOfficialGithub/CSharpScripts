﻿//Delcare a method that calculates the sum of an unknown number of integers

double Sum(params int[] numbers)
{
    int total = 0;
    int count = 0;
    foreach(int number in numbers)
    {
        total += number;
        count++;
    }
    return (double) total /count;
}
