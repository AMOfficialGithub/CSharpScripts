﻿/**Create a jaggedarray which contains 3 friends array, in which two family members
 * should be stored
 * Introduce Family Members from Different Families to each other via console.
 */
//JaggedArray Initalization
string[][] friendsArray = new string[3][]
{
   new string []  {"Jason M","Henry M" },
   new string [] {"Jenny B","Barbra B" },
   new string [] {"April R","Michael R" }
};

//The outer loop goes over the rows
for (int i = 0; i < friendsArray.Length; i++)
{
    //The inner loop goes over the elements
    for (int k = 0; k < friendsArray[i].Length; k++)
    {
        // Accessing the current family member and the family member of the other array
        string currentMember = friendsArray[i][k];
        string otherMember = friendsArray[(i + 1) % friendsArray.Length][k % friendsArray[(i + 1) % friendsArray.Length].Length];

        // Printing the introduction
        Console.WriteLine("Hello {0}, this is {1}", currentMember, otherMember);
    }
}
