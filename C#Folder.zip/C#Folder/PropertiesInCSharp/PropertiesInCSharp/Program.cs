﻿using PropertiesInCSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

Car myCar = new Car();
//Setting the name with the setter
myCar.Name = "MyAudiA3";
//Calling the getName property, which returns the underscore name
Console.WriteLine(myCar.Name);