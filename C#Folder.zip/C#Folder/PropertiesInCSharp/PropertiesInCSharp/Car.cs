﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesInCSharp
{

        internal class Car
        {
        //Privat member variables
            private string _name;
            private int _hp;
            private string _color;

        //Creating a property by typing pro and pressing tab
        //Encapsulated method
        public string Name {
            //Get accessor
            get { return _name; }
            //Store value of _name of value, using the main program in Program.cs
            //Set accessor
            set {
                if (value == "") {
                    _name = "Hello World Default Name";
                }
                else
                {
                    _name = value;
                } }
        }
        public Car()
            {
                Console.WriteLine("I am the default constructor");
                _name = "Car";
                _hp = 25;
                _color = "red";
            }

            private void Drive()
            {
                Console.WriteLine("Car is driving");
            }

            public void Stop()
            {
                Console.WriteLine("Car is stopped");
            }

            public void Details()
            {
                Console.WriteLine($"Name: {_name}, HP: {_hp}, Color: {_color}");
            }

        }
    }

