﻿using System.ComponentModel;

Console.WriteLine("Put something here, user!");
string input = Console.ReadLine(); //Asking for the user input. Stored in a string called input.
Console.WriteLine("I have returned, {0}",input);

//CREATE A CALCULATOR THAT ADDS

Console.WriteLine(Add(1,4));

int Add(int one, int two)
{
    return one + two;
}

//CHALLENGE: CREATE A CALCULATOR THAT TAKES IN THE USER RESPONSE AND ADDS

int AddThese()
{
    Console.WriteLine("Please enter in a number");
    string one1 = Console.ReadLine();
    int converseMe = Int32.Parse(one1);
    Console.WriteLine("Please enter in the second number");
    string two2 = Console.ReadLine();
    int converseMe2 = Int32.Parse(two2);

    return converseMe + converseMe2;

}
Console.WriteLine(AddThese());