﻿
int num1 = 5;
int num2 = 3;
int num3;

//Unary operator
num3 = -num1; //Stores the variable of num3 - num1 into num3
Console.WriteLine("num3 is {0}", num3);

//Logical operators

bool isSunny = true;
Console.WriteLine("Is it sunny?? {0}", !isSunny); //This will not be sunny

//increment operators
int num = 0;
num++; //Adds it by one
Console.WriteLine(num);
Console.WriteLine(num++);//Only takes effect in the next line
Console.WriteLine(++num);//Takes effect in the immediate line

//Decrement Operator
Console.WriteLine(num--);//Only takes effect in the next line   
Console.WriteLine(--num);//Takes effect immediatly


//Relational and type operators
bool isLower;
isLower = num1 > num2;
Console.WriteLine("result of num1 < num2 is {0}", isLower);
//Calculations
int result;

result = num1 + num2;
Console.WriteLine("Result of num1 and num2 is {0}",result);

result = num1 - num2;
Console.WriteLine("Result of num1 and num2 is {0}", result);

result = num1 / num2;
Console.WriteLine("Result of num1 and num2 is {0}", result);
result = num1 * num2;
Console.WriteLine("Result of num1 and num2 is {0}", result);
//Modulo
result = num1 % num2;
Console.WriteLine("Result of num1 and num2 is {0} ", result);

//Equality operator
bool isEqual;
isEqual = num1 == num2;

Console.WriteLine("Result of num1 == num2 is {0}", isEqual);

isEqual = num1 != num2;
Console.WriteLine("Result of num1 == num2 is {0}", isEqual);

//Conditional operators
bool isLowerAndSunny;
isLowerAndSunny = isLower && isSunny; //Both statements must be true else false
Console.WriteLine(isLowerAndSunny);
//Condition 1 or Condition 2 must be true.
isLowerAndSunny = isLower || isSunny; //One can be true for the statement to be true
Console.WriteLine(isLowerAndSunny);