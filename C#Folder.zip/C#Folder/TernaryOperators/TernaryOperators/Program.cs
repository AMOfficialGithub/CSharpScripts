﻿//condition ? first_expression : second_expression;
//Condition has to be either true or false
//The conditional operator is right - associative
//The expression a? b : c? d: e
//Is evaluated as a ? b : ( c ? d: e),
//not as (a? b : c) ? d : e.
//The conditional operator cannot be overloaded.

//Temperature in Celcius
int temperature = -5;
string stateOfMatter;

if(temperature < 0)
{
    stateOfMatter = "Solid";
}
else
{
    stateOfMatter = "Liquid";
}
Console.WriteLine("State of matter is {0}", stateOfMatter);

//Ternary Operator/Enhanced If Statement

temperature += 30; //Increasing the temperature by 30 degrees
//if the temperature is less than 0 do solid, else do liquid
stateOfMatter = temperature < 0 ? "solid" : "liquid";

//CHALLENGE add the gas state of matter to the options
//The condition is temperature, with the option of solid. Then, the conndition is 
//temperature again, with the option of gas or liquid
stateOfMatter = temperature < 0 ? "solid" : (temperature >= 100 ? "gas" : "liquid");

Console.WriteLine(stateOfMatter);
