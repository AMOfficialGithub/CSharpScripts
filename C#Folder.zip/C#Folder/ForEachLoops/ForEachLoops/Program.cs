﻿
//Creating a new Array
using System.Diagnostics.Metrics;
using System.Reflection;

int[] nums = new int[10];

//Put values into the integer array
for(int i = 0; i < 10; i++)
{
    nums[i] = i;//At index 0, value will be 0, at index 1, value will be 1 up to 9.
}
for(int j = 0; j <nums.Length; j ++)
{
    Console.WriteLine("Element {0} = {1}", j, nums[j]);
}

//For each loop alternative

int counter = 0;
foreach(int k in nums)
{
    Console.WriteLine("Element{0} at value {1}",counter,k);
    counter++;
   
}

//CHALLENGE CREATE AN ARRAY WITH 5 OF YOUR BEST FRIENDS
//CREATE A FOR EACH LOOP THAT GREETS ALL OF THEM

string[] bestFriends = new string[5];
bestFriends[0] = "April";
bestFriends[1] = "Jenny";
bestFriends[2] = "Jafril";
bestFriends[3] = "Besty";
bestFriends[4] = "Sam";

int counter2 = 0;
foreach (string e in bestFriends)
{
    Console.WriteLine("Element{0} at Hello {1}", counter2, e);
   counter2++;

}
