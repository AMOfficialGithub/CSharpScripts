﻿
/**
 * Create an application with a score, highscore and a highscorePlayer.
Create a method which has two parameters, one for the score and one for the playerName.
When ever that method is called, it should be checked if the score of the player is higher than the highscore, if so, 
"New highscore is + " score" and in another line "New highscore holder is " + 
playerName - should be written onto the console, if not "The old highscore of " + highscore + 
\" could not be broken and is still held by " + highscorePlayer.
Consider which variables are required globally and which ones locally.
 * */

int score = 25, highscore = 125;
string highscorePlayer = "Sandy";

//Void is used if the method is going to write to the console. There is no return
void PlayerInfo(int newScore, string playerName)
{
    
    if (newScore > highscore)
    {
        highscore = newScore;//Assign highscore to the newScore
        highscorePlayer = playerName; //Assign the highschorePlayer to playerName
        Console.WriteLine($"New highscore is {newScore}");
        Console.WriteLine($"New highscore holder is {playerName}");
    }
    else
    {
        Console.WriteLine($"The old highscore of {highscore} could not be broken and is still held by {highscorePlayer}");
    }
}
PlayerInfo(100,"Andy");//Call the method with the arguements inside